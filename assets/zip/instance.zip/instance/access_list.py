access_list = ["dragonyang92@gmail.com",
               "sb2896@columbia.edu",#simon
               "simon.billinge@gmail.com",#simon
               "mwt2115@columbia.edu",#max
               "ly2364@columbia.edu",#long
               "cl3077@columbia.edu",#tim
               "cw2981@columbia.edu",#chris
               "sb3519@columbia.edu",#soham
               "st3107@columbia.edu",#songsheng
               "yr2369@columbia.edu",#yevgeny
               "emil.bozin@gmail.com",#emil
               "pavol.juhas@gmail.com",#pavol
               "rkoch177@gmail.com",#robert
               "matttucker007@gmail.com",#matt
               "zyroc1990@gmail.com",#yuanpeng zhang, matt postdoc
               "htv2008@columbia.edu",#hung tien vuong
               "youqin5912@gmail.com",#bo jiang, kate postdoc
               "cmrg.mac@gmail.com",#marshall mcdonnell, matt postdoc
               "rhiannon.garrard@stonybrook.edu",#rhiannon garrard, simon stonybrook friend
               "karoly.kozma@stonybrook.edu",#karoly kozma, simon stonybrook friend
               "rp3001@columbia.edu",#rohan pokratath
               "vg2471@columbia.edu",#vahe gharakhanyan
               "sethkriti14@gmail.com",#kriti seth
               "rg3142@columbia.edu",#ran gu
               "sh4045@columbia.edu",#sani harouna-mayer
               "nkt2111@columbia.edu",#Nancy Knight Thomas
               "bo2220@columbia.edu",#Berrak Ozer
               "thygesen1212@gmail.com",#Emil Thyge Skaaning Kjær
               "dy2403@barnard.edu",#Daniela
               ]