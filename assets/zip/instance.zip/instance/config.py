
config = {
	'SECRET_KEY' : 'xpd28id2_lirr_penn_123',					# Necessary setup for the Google Oauth2 client. Secrets file generated through our google API account 
																# which is currently owned by Liz -- will need to be transferred at some point
	'GOOGLE_OAUTH2_CLIENT_SECRETS_FILE' : 'instance/credentials.json',
	'MONGODB_SETTINGS' : {
    	'db': 'prototype_pdfitc',
    	'host': 'mongodb://app:apppwd7@ds151814.mlab.com:51814/prototype_pdfitc' # Setup for MongoDB. Also currently owned by Liz as a prototype. Will need account owned by PDFitc
	},
	'DASH_BASE_URL' : '/viz/'
}