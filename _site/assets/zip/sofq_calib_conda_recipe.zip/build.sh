$PYTHON setup.py install
