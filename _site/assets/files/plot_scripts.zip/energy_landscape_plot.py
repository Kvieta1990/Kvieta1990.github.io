"""
Random 3D Energy Landscape Plot
--------------------------------
Generates a smooth, random-looking energy surface E(x, y) over a 2D space
and renders it as an interactive 3D surface plot using Plotly.

Requirements:
    pip install numpy scipy plotly
"""

import numpy as np
from scipy.ndimage import gaussian_filter
import plotly.graph_objects as go

# ----------------------------
# 1. Build the 2D grid
# ----------------------------
n_points = 150                     # grid resolution
x = np.linspace(-5, 5, n_points)
y = np.linspace(-5, 5, n_points)
X, Y = np.meshgrid(x, y)

# ----------------------------
# 2. Generate a random landscape
# ----------------------------
# Start from random noise, then smooth it so it looks like a
# physically plausible energy landscape (hills and basins)
# instead of pure noise.
rng = np.random.default_rng(seed=42)   # change/remove seed for different landscapes each run
raw_noise = rng.normal(size=(n_points, n_points))

# Smooth the noise at a couple of different length scales and combine
# them, which gives a landscape with both broad features and finer detail.
smooth_broad = gaussian_filter(raw_noise, sigma=15)
smooth_fine = gaussian_filter(raw_noise, sigma=4)
Z = 3.0 * smooth_broad + 0.8 * smooth_fine

# Add a few random low-amplitude Gaussian "bumps" for texture/barriers
n_features = 5
for _ in range(n_features):
    cx = rng.uniform(-4, 4)
    cy = rng.uniform(-4, 4)
    amp = rng.uniform(0.5, 2.5)    # positive = barrier/hill
    width = rng.uniform(0.8, 2.0)
    Z += amp * np.exp(-((X - cx) ** 2 + (Y - cy) ** 2) / (2 * width ** 2))

# ----------------------------
# 2b. Carve out explicit local minima (wells), one deeper than the rest
# ----------------------------
# Each well: (center_x, center_y, depth, width). Depth is how far the well
# pulls the energy down at its center (larger = deeper well).
wells = [
    (-3.0, -2.5, 6.0, 1.3),   # local minimum 1
    (2.5, 3.0, 6.5, 1.3),     # local minimum 2
    (3.2, -3.0, 7.0, 1.3),    # local minimum 3
    (-1.0, 1.5, 11.0, 1.5),   # GLOBAL minimum (deepest well)
]

for cx, cy, depth, width in wells:
    Z -= depth * np.exp(-((X - cx) ** 2 + (Y - cy) ** 2) / (2 * width ** 2))

# Normalize so the energy scale is easy to read (arbitrary units)
Z = (Z - Z.min()) / (Z.max() - Z.min())   # rescale to [0, 1]
Z = Z * 10.0                              # rescale to [0, 10] "energy units"

# ----------------------------
# 3. Build the Plotly 3D surface plot
# ----------------------------
fig = go.Figure(
    data=[
        go.Surface(
            x=X,
            y=Y,
            z=Z,
            colorscale="Viridis",
            colorbar=dict(
                title=dict(text="Energy<br> <br> ", font=dict(size=32), side="top"),
                tickvals=[Z.min(), Z.max()],
                ticktext=["Low", "High"],
                tickfont=dict(size=24),
                ticks="",
                len=0.6,
                y=0.35,
            ),
            contours={
                "z": {
                    "show": True,
                    "usecolormap": True,
                    "highlightcolor": "limegreen",
                    "project_z": True,
                }
            },
        )
    ]
)

fig.update_layout(
    title="Random Energy Landscape",
    scene=dict(
        xaxis=dict(title="", showticklabels=False),
        yaxis=dict(title="", showticklabels=False),
        zaxis=dict(
            title=dict(text="Energy", font=dict(size=32)),
            showticklabels=False,
        ),
        camera=dict(eye=dict(x=1.4, y=1.4, z=0.9)),
    ),
    width=900,
    height=750,
    margin=dict(l=0, r=0, t=50, b=0),
)

# ----------------------------
# 4. Show / save
# ----------------------------
fig.show()

# Optionally save as a standalone interactive HTML file:
# fig.write_html("energy_landscape.html")
