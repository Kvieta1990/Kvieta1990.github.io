"""
Boltzmann Probability Density - 2D Contour Plot
--------------------------------------------------
Reuses the same random energy landscape E(x, y) and Boltzmann probability
density P(x, y) as before, but renders it as a 2D contour plot (top-down
view) instead of a 3D surface.

Requirements:
    pip install numpy scipy plotly
"""

import numpy as np
from scipy.ndimage import gaussian_filter
import plotly.graph_objects as go

# ----------------------------
# 1. Build the 2D grid
# ----------------------------
n_points = 150                     # grid resolution
x = np.linspace(-5, 5, n_points)
y = np.linspace(-5, 5, n_points)
X, Y = np.meshgrid(x, y)
dx = x[1] - x[0]
dy = y[1] - y[0]

# ----------------------------
# 2. Generate the same random energy landscape as before
# ----------------------------
rng = np.random.default_rng(seed=42)   # same seed -> same landscape
raw_noise = rng.normal(size=(n_points, n_points))

smooth_broad = gaussian_filter(raw_noise, sigma=15)
smooth_fine = gaussian_filter(raw_noise, sigma=4)
E = 3.0 * smooth_broad + 0.8 * smooth_fine

n_features = 5
for _ in range(n_features):
    cx = rng.uniform(-4, 4)
    cy = rng.uniform(-4, 4)
    amp = rng.uniform(0.5, 2.5)
    width = rng.uniform(0.8, 2.0)
    E += amp * np.exp(-((X - cx) ** 2 + (Y - cy) ** 2) / (2 * width ** 2))

wells = [
    (-3.0, -2.5, 6.0, 1.3),   # local minimum 1
    (2.5, 3.0, 6.5, 1.3),     # local minimum 2
    (3.2, -3.0, 7.0, 1.3),    # local minimum 3
    (-1.0, 1.5, 11.0, 1.5),   # GLOBAL minimum (deepest well)
]
for cx, cy, depth, width in wells:
    E -= depth * np.exp(-((X - cx) ** 2 + (Y - cy) ** 2) / (2 * width ** 2))

# Rescale to [0, 10] "energy units", exactly as in the energy landscape plot
E = (E - E.min()) / (E.max() - E.min())
E = E * 10.0

# ----------------------------
# 3. Compute the Boltzmann probability density
# ----------------------------
kT = 1.0   # thermal energy scale (k_B * T). Lower -> sharper peak at global min.

boltzmann_factor = np.exp(-E / kT)
partition_function = np.sum(boltzmann_factor) * dx * dy   # discretized integral
P = boltzmann_factor / partition_function                  # normalized probability density

# The probability density spans several orders of magnitude between the deep
# global minimum and the shallower local minima, so a *linear* color scale
# makes the shallower basins nearly invisible. Plotting log10(P) instead
# compresses that range and reveals all the basins at once, while the
# colorbar is still labeled "Probability" for the reader.
logP = np.log10(P)

# ----------------------------
# 4. Build the Plotly 2D contour plot of P(x, y)
# ----------------------------
fig = go.Figure(
    data=[
        go.Contour(
            x=x,
            y=y,
            z=logP,
            colorscale="Viridis",
            contours=dict(
                showlabels=False,
                coloring="fill",
            ),
            line=dict(width=0.5),
            colorbar=dict(
                title=dict(text="Probability<br> <br> ", font=dict(size=32), side="top"),
                tickvals=[logP.min(), logP.max()],
                ticktext=["Low", "High"],
                tickfont=dict(size=24),
                ticks="",
                len=0.6,
                y=0.35,
            ),
        )
    ]
)

fig.update_layout(
    title=f"Boltzmann Probability Density - Contour View (kT = {kT})",
    xaxis=dict(title="", showticklabels=False),
    yaxis=dict(title="", showticklabels=False, scaleanchor="x", scaleratio=1),
    width=800,
    height=750,
    margin=dict(l=0, r=0, t=50, b=0),
)

# ----------------------------
# 5. Show / save
# ----------------------------
fig.show()

# Optionally save as a standalone interactive HTML file:
# fig.write_html("boltzmann_contour.html")
