class ToolValidateFailedError(Exception):
    description = "Tool Provider Validate failed"
