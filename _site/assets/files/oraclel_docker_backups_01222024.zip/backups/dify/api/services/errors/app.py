class MoreLikeThisDisabledError(Exception):
    pass
