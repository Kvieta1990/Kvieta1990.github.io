from blinker import signal

# sender: document
document_index_created = signal('document-index-created')
