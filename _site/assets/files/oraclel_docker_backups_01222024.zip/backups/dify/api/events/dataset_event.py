from blinker import signal

# sender: dataset
dataset_was_deleted = signal('dataset-was-deleted')
