from blinker import signal

# sender: document
document_was_deleted = signal('document-was-deleted')
