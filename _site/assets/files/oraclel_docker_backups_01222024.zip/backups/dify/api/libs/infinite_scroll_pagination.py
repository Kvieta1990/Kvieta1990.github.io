# -*- coding:utf-8 -*-

class InfiniteScrollPagination:
    def __init__(self, data, limit, has_more):
        self.data = data
        self.limit = limit
        self.has_more = has_more
