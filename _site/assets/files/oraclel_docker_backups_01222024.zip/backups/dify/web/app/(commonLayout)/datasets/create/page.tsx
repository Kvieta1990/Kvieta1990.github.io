import React from 'react'
import DatasetUpdateForm from '@/app/components/datasets/create'

type Props = {}

const DatasetCreation = async (props: Props) => {
  return (
    <DatasetUpdateForm />
  )
}

export default DatasetCreation
