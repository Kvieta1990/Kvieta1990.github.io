import React from 'react'

type Props = {}

const page = (props: Props) => {
  return (
    <div>dataset detail api</div>
  )
}

export default page
